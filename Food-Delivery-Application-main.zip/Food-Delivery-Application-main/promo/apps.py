from django.apps import AppConfig


class PromoConfig(AppConfig):
    name = 'promo'
