from django.contrib import admin
from .models import PromoCode

admin.site.register(PromoCode)
