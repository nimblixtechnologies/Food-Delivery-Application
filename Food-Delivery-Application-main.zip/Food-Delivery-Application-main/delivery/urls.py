from django.urls import path
from .views import (
    DeliveryStatusView,
    AvailableOrdersView,
    AcceptOrderView,
    DeliveryCreateView,
    DeliveryUpdateView,
    UpdateDeliveryStatusView,
)


urlpatterns = [
    path('status/', DeliveryStatusView.as_view(), name='delivery-status'),
    path('orders/available/', AvailableOrdersView.as_view(), name='available-orders'),
    path('orders/<int:order_id>/accept/', AcceptOrderView.as_view(), name='accept-order'),
    path('', DeliveryCreateView.as_view(), name='delivery-create'),
    path('<int:pk>/', DeliveryUpdateView.as_view(), name='delivery-update'),
    path('<int:pk>/status/', UpdateDeliveryStatusView.as_view(), name='update-delivery-status'),
]
