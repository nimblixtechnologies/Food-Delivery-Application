from .permissions import IsDeliveryPartner
from rest_framework import generics, permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView
from django.shortcuts import get_object_or_404
from .models import Delivery, DeliveryProfile
from .serializers import DeliverySerializer, DeliveryProfileSerializer
from orders.models import Order
from orders.serializers import OrderSerializer
from django.db import transaction

def get_driver_profile(user):
    try:
        return DeliveryProfile.objects.get(user=user)
    except DeliveryProfile.DoesNotExist:
        return None


class DeliveryStatusView(APIView):
    permission_classes = [permissions.IsAuthenticated, IsDeliveryPartner]

    def get(self, request):
        deliveries = Delivery.objects.filter(delivery_partner=request.user)
        return Response(DeliverySerializer(deliveries, many=True).data)

    def post(self, request):
        profile, _ = DeliveryProfile.objects.get_or_create(user=request.user)

        if 'is_available' in request.data:
            profile.is_available = str(request.data['is_available']).lower() == 'true'

        if 'current_location' in request.data:
            profile.current_location = request.data['current_location']

        profile.save()
        return Response(DeliveryProfileSerializer(profile).data)


class AvailableOrdersView(generics.ListAPIView):
    serializer_class = OrderSerializer
    permission_classes = [permissions.IsAuthenticated, IsDeliveryPartner]

    def get_queryset(self):
        # Logic to return orders ready for pickup and nearby (mock proximity)
        return Order.objects.filter(status='PREPARING', delivery_partner__isnull=True)

class AcceptOrderView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, order_id):

        profile = get_driver_profile(request.user)

        if not profile:
            return Response(
                {"error": "Delivery profile not found. Create profile first."},
                status=status.HTTP_400_BAD_REQUEST
            )

        if not profile.is_available:
            return Response({"error": "Driver not available"}, status=400)

        with transaction.atomic():

            order = Order.objects.select_for_update().filter(
                id=order_id,
                delivery_partner__isnull=True
            ).first()

            if not order:
                return Response(
                    {"error": "Order already accepted by another driver"},
                    status=400
                )

            order.delivery_partner = request.user
            order.status = 'PICKED_UP'
            order.save()

            profile.is_available = False
            profile.save()

        return Response(OrderSerializer(order).data)


class DeliveryCreateView(generics.CreateAPIView):
    queryset = Delivery.objects.all()
    serializer_class = DeliverySerializer
    permission_classes = [permissions.IsAuthenticated, IsDeliveryPartner]

class DeliveryUpdateView(generics.UpdateAPIView):
    queryset = Delivery.objects.all()
    serializer_class = DeliverySerializer
    permission_classes = [permissions.IsAuthenticated, IsDeliveryPartner]
    
class UpdateDeliveryStatusView(APIView):
    permission_classes = [permissions.IsAuthenticated, IsDeliveryPartner]

    def post(self, request, pk):
        delivery = get_object_or_404(Delivery, id=pk, delivery_partner=request.user)

        new_status = request.data.get("status")

        allowed = ["PICKED_UP", "ON_THE_WAY", "DELIVERED"]

        if new_status not in allowed:
            return Response({"error": "Invalid status"}, status=400)

        delivery.status = new_status
        delivery.save()

        return Response(DeliverySerializer(delivery).data)



class AvailableOrdersView(generics.ListAPIView):
    serializer_class = OrderSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        profile = get_driver_profile(self.request.user)

        if not profile or not profile.is_available:
            return Order.objects.none()

        return Order.objects.filter(
            status='PREPARING',
            delivery_partner__isnull=True
        )
    
    
class AcceptOrderView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, order_id):
        profile = get_driver_profile(request.user)

        if not profile:
            return Response(
            {"error": "Delivery profile not found. Create profile first."},
            status=status.HTTP_400_BAD_REQUEST
            )

        if not profile.is_available:
            return Response({"error": "Driver not available"}, status=400)

        order = get_object_or_404(Order, id=order_id, delivery_partner__isnull=True)

        order.delivery_partner = request.user
        order.status = 'PICKED_UP'
        order.save()

        profile.is_available = False   # driver now busy
        profile.save()

        return Response(OrderSerializer(order).data)


class DeliveryCreateView(generics.CreateAPIView):
    queryset = Delivery.objects.all()
    serializer_class = DeliverySerializer
    permission_classes = [permissions.IsAuthenticated]

class DeliveryUpdateView(generics.UpdateAPIView):
    queryset = Delivery.objects.all()
    serializer_class = DeliverySerializer
    permission_classes = [permissions.IsAuthenticated]
    
class UpdateDeliveryStatusView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, pk):
        delivery = get_object_or_404(Delivery, id=pk, delivery_partner=request.user)

        new_status = request.data.get("status")

        allowed = ["PICKED_UP", "ON_THE_WAY", "DELIVERED"]

        if new_status not in allowed:
            return Response({"error": "Invalid status"}, status=400)

        delivery.status = new_status
        delivery.save()

        return Response(DeliverySerializer(delivery).data)
