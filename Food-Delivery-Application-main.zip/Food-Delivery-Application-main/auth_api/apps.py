from django.apps import AppConfig


class AuthApiConfig(AppConfig):
    name = 'auth_api'
