import { useState, useEffect } from 'react';
import { delivery as deliveryAPI } from '../../api';
import { useToast } from '../../context/index.jsx';

export default function DeliveryDashboard() {
  const toast = useToast();
  const [profile, setProfile]   = useState(null);
  const [available, setAvailable] = useState([]);
  const [myDeliveries, setMyDeliveries] = useState([]);
  const [loading, setLoading]   = useState(true);
  const [accepting, setAccepting] = useState(null);
  const [updatingDelivery, setUpdatingDelivery] = useState(null);
  const [locationInput, setLocationInput] = useState('');
  const [tab, setTab]           = useState('available');

  const load = async () => {
    setLoading(true);
    try {
      const [avail, myD] = await Promise.all([
        deliveryAPI.availableOrders().catch(() => []),
        deliveryAPI.myDeliveries().catch(() => []),
      ]);
      setAvailable(avail);
      setMyDeliveries(myD);
    } catch {}

    // Get profile by posting with empty data to get current profile
    try {
      const p = await deliveryAPI.updateStatus({});
      setProfile(p);
      setLocationInput(p.current_location || '');
    } catch {}
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const toggleAvailability = async () => {
    try {
      const p = await deliveryAPI.updateStatus({ is_available: !profile?.is_available });
      setProfile(p);
      toast(p.is_available ? 'You are now available for orders' : 'You are now offline', 'info');
    } catch (err) { toast('Could not update availability', 'error'); }
  };

  const updateLocation = async () => {
    if (!locationInput.trim()) return;
    try {
      const p = await deliveryAPI.updateStatus({ current_location: locationInput });
      setProfile(p);
      toast('Location updated', 'success');
    } catch { toast('Could not update location', 'error'); }
  };

  const acceptOrder = async (orderId) => {
    setAccepting(orderId);
    try {
      await deliveryAPI.acceptOrder(orderId);
      toast(`Order #${orderId} accepted!`, 'success');
      load();
    } catch (err) {
      toast(err?.data?.error || 'Could not accept order', 'error');
    } finally { setAccepting(null); }
  };

  const updateDeliveryStatus = async (deliveryId, status) => {
    setUpdatingDelivery(deliveryId);
    try {
      await deliveryAPI.updateDeliveryStatus(deliveryId, status);
      toast(`Status updated to ${status}`, 'success');
      load();
    } catch (err) {
      toast(err?.data?.error || 'Could not update', 'error');
    } finally { setUpdatingDelivery(null); }
  };

  const NEXT = { ASSIGNED:'PICKED_UP', PICKED_UP:'ON_THE_WAY', ON_THE_WAY:'DELIVERED' };
  const NEXT_LABEL = { ASSIGNED:'Mark Picked Up', PICKED_UP:'On The Way', ON_THE_WAY:'Mark Delivered' };

  if (loading) return <div className="loading-wrap"><div className="spinner" /></div>;

  return (
    <div className="page fade-in">
      <h1 className="page-title">🛵 Delivery Dashboard</h1>

      {/* Status card */}
      <div className="card" style={{ marginBottom:24 }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', flexWrap:'wrap', gap:16 }}>
          <div>
            <div style={{ fontFamily:'var(--display)', fontWeight:700, fontSize:16, marginBottom:4 }}>Your Status</div>
            <span className={`badge ${profile?.is_available ? 'badge-green' : 'badge-red'}`} style={{ fontSize:13 }}>
              {profile?.is_available ? '🟢 Online — Ready for orders' : '🔴 Offline'}
            </span>
          </div>
          <button
            className={`btn ${profile?.is_available ? 'btn-danger' : 'btn-success'}`}
            onClick={toggleAvailability}
          >
            {profile?.is_available ? 'Go Offline' : 'Go Online'}
          </button>
        </div>

        <div className="divider" />

        <div style={{ display:'flex', gap:10, alignItems:'flex-end' }}>
          <div style={{ flex:1 }}>
            <label className="form-label">Current Location</label>
            <input className="form-input" value={locationInput} onChange={e => setLocationInput(e.target.value)} placeholder="e.g. Koramangala, Bengaluru" />
          </div>
          <button className="btn btn-secondary" onClick={updateLocation}>Update</button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid3" style={{ marginBottom:28 }}>
        {[
          ['📦 Available', available.length, 'var(--teal)'],
          ['🔄 Active', myDeliveries.filter(d => d.status !== 'DELIVERED').length, 'var(--accent)'],
          ['✅ Completed', myDeliveries.filter(d => d.status === 'DELIVERED').length, 'var(--green)'],
        ].map(([label, val, color]) => (
          <div key={label} className="card" style={{ textAlign:'center' }}>
            <div style={{ fontFamily:'var(--display)', fontSize:36, fontWeight:800, color }}>{val}</div>
            <div style={{ color:'var(--muted)', fontSize:13, marginTop:4 }}>{label}</div>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div style={{ display:'flex', gap:4, background:'var(--surface)', borderRadius:'var(--r-md)', padding:4, width:'fit-content', marginBottom:20 }}>
        {[['available','Available Orders'], ['active','My Active']].map(([k, label]) => (
          <button key={k} style={{ padding:'8px 20px', borderRadius:'var(--r-sm)', fontSize:14, fontWeight:600, color: tab===k ? 'var(--text)' : 'var(--muted)', background: tab===k ? 'var(--navy2)' : 'none', border:'none', cursor:'pointer' }} onClick={() => setTab(k)}>
            {label}
          </button>
        ))}
      </div>

      {/* Available orders */}
      {tab === 'available' && (
        available.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">🛵</div>
            <h3>No orders available right now</h3>
            <p>Make sure you are online to receive orders</p>
          </div>
        ) : (
          <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
            {available.map(order => (
              <div key={order.id} className="card fade-in" style={{ padding:'18px 22px' }}>
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', flexWrap:'wrap', gap:10, marginBottom:12 }}>
                  <div>
                    <div style={{ fontFamily:'var(--display)', fontWeight:700, fontSize:16 }}>Order #{order.id}</div>
                    <div style={{ color:'var(--muted)', fontSize:13, marginTop:3 }}>📍 {order.delivery_address}</div>
                    <div style={{ color:'var(--muted)', fontSize:13 }}>💰 ₹{order.total_amount}</div>
                  </div>
                  <span className="badge badge-teal">PREPARING</span>
                </div>
                <div style={{ display:'flex', flexWrap:'wrap', gap:6, marginBottom:14 }}>
                  {order.items?.map((it, i) => (
                    <span key={i} style={{ padding:'2px 10px', background:'var(--navy2)', border:'1px solid var(--border)', borderRadius:20, fontSize:12 }}>{it.quantity}× {it.menu_item_name}</span>
                  ))}
                </div>
                <button
                  className="btn btn-primary"
                  disabled={accepting === order.id || !profile?.is_available}
                  onClick={() => acceptOrder(order.id)}
                >
                  {accepting === order.id ? '⏳ Accepting…' : '✅ Accept Order'}
                </button>
                {!profile?.is_available && <span style={{ marginLeft:12, fontSize:12, color:'var(--red)' }}>Go online to accept</span>}
              </div>
            ))}
          </div>
        )
      )}

      {/* My active deliveries */}
      {tab === 'active' && (
        myDeliveries.filter(d => d.status !== 'DELIVERED').length === 0 ? (
          <div className="empty-state"><div className="empty-icon">📭</div><h3>No active deliveries</h3></div>
        ) : (
          <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
            {myDeliveries.filter(d => d.status !== 'DELIVERED').map(d => (
              <div key={d.id} className="card" style={{ padding:'18px 22px' }}>
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', flexWrap:'wrap', gap:10, marginBottom:12 }}>
                  <div style={{ fontFamily:'var(--display)', fontWeight:700 }}>Delivery #{d.id} · Order #{d.order}</div>
                  <span className={`badge status-${d.status}`} style={{ padding:'4px 12px', borderRadius:20, fontSize:12, fontWeight:700 }}>{d.status}</span>
                </div>
                {NEXT[d.status] && (
                  <button
                    className="btn btn-primary btn-sm"
                    disabled={updatingDelivery === d.id}
                    onClick={() => updateDeliveryStatus(d.id, NEXT[d.status])}
                  >
                    {updatingDelivery === d.id ? '⏳ Updating…' : NEXT_LABEL[d.status]}
                  </button>
                )}
              </div>
            ))}
          </div>
        )
      )}
    </div>
  );
}
