import { useState, useEffect } from 'react';
import { delivery as deliveryAPI } from '../../api';
import { useToast } from '../../context/index.jsx';

export default function DeliveryHistory() {
  const toast = useToast();
  const [deliveries, setDeliveries] = useState([]);
  const [loading, setLoading]       = useState(true);

  useEffect(() => {
    deliveryAPI.myDeliveries()
      .then(setDeliveries)
      .catch(() => toast('Could not load history', 'error'))
      .finally(() => setLoading(false));
  }, []);

  const done = deliveries.filter(d => d.status === 'DELIVERED');
  const earnings = done.length * 40; // mock: ₹40 per delivery

  if (loading) return <div className="loading-wrap"><div className="spinner" /></div>;

  return (
    <div className="page fade-in">
      <h1 className="page-title">📋 Delivery History</h1>

      <div className="grid3" style={{ marginBottom:28 }}>
        {[
          ['Total Deliveries', deliveries.length, 'var(--teal)'],
          ['Completed', done.length, 'var(--green)'],
          ['Est. Earnings', `₹${earnings}`, 'var(--accent)'],
        ].map(([label, val, color]) => (
          <div key={label} className="card" style={{ textAlign:'center' }}>
            <div style={{ fontFamily:'var(--display)', fontSize:34, fontWeight:800, color }}>{val}</div>
            <div style={{ color:'var(--muted)', fontSize:13, marginTop:4 }}>{label}</div>
          </div>
        ))}
      </div>

      {deliveries.length === 0 ? (
        <div className="empty-state"><div className="empty-icon">📋</div><h3>No deliveries yet</h3><p>Accept your first order from the dashboard</p></div>
      ) : (
        <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
          {deliveries.map(d => (
            <div key={d.id} className="card" style={{ display:'flex', justifyContent:'space-between', alignItems:'center', flexWrap:'wrap', gap:12, padding:'16px 20px' }}>
              <div>
                <div style={{ fontFamily:'var(--display)', fontWeight:700 }}>Delivery #{d.id}</div>
                <div style={{ color:'var(--muted)', fontSize:13, marginTop:2 }}>Order #{d.order} · Assigned {new Date(d.assigned_at).toLocaleString('en-IN')}</div>
              </div>
              <span className={`badge status-${d.status}`} style={{ padding:'4px 12px', borderRadius:20, fontSize:12, fontWeight:700 }}>{d.status}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
