import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth, useToast } from '../context/index.jsx';

export default function AuthPage() {
  const { login, register } = useAuth();
  const toast  = useToast();
  const nav    = useNavigate();

  const [mode, setMode]   = useState('login');
  const [busy, setBusy]   = useState(false);
  const [errors, setErrors] = useState({}); // field-level errors from Django
  const [form, setForm]   = useState({
    username: '', password: '', email: '', phone_number: '', role: 'CUSTOMER'
  });

  const set = k => e => {
    setForm(f => ({ ...f, [k]: e.target.value }));
    setErrors(er => ({ ...er, [k]: null, non_field: null })); // clear on type
  };

  const roleHome = { CUSTOMER: '/home', RESTAURANT: '/restaurant', DELIVERY: '/delivery' };

  // Parse Django error response into field errors
  const parseErrors = (data) => {
    if (!data) return { non_field: 'Something went wrong. Please try again.' };
    const errs = {};
    Object.entries(data).forEach(([key, val]) => {
      const msg = Array.isArray(val) ? val.join(' ') : String(val);
      if (key === 'non_field_errors' || key === 'detail' || key === 'error') {
        errs.non_field = msg;
      } else {
        errs[key] = msg;
      }
    });
    if (Object.keys(errs).length === 0) errs.non_field = JSON.stringify(data);
    return errs;
  };

  const submit = async e => {
    e.preventDefault();
    setBusy(true);
    setErrors({});
    try {
      let profile;
      if (mode === 'login') {
        // Django users/views.py LoginView uses field "mobile" in request.data
        // but authenticates via authenticate(username=mobile, password=password)
        // So we send username as the value for the "mobile" field
        profile = await login(form.username, form.password);
      } else {
        // RegisterSerializer fields: username, email, password, phone_number, role
        profile = await register({
          username:     form.username,
          password:     form.password,
          email:        form.email,
          phone_number: form.phone_number,
          role:         form.role,
        });
      }
      toast(`Welcome, ${profile.username}! 🎉`, 'success');
      nav(roleHome[profile.role] || '/home');
    } catch (err) {
      const parsed = parseErrors(err?.data);
      setErrors(parsed);
      // Also show a toast with the main message
      toast(parsed.non_field || Object.values(parsed)[0] || 'Registration failed', 'error');
    } finally {
      setBusy(false);
    }
  };

  const switchMode = () => { setMode(m => m === 'login' ? 'register' : 'login'); setErrors({}); };

  return (
    <div style={S.wrap}>
      <div style={S.bg} />
      <div style={S.card}>

        {/* Logo */}
        <div style={{ textAlign:'center', fontFamily:'var(--display)', fontWeight:800, fontSize:26, color:'var(--accent)', marginBottom:24 }}>
          Quick<span style={{ color:'var(--teal)' }}>Bite</span>
        </div>

        <h2 style={S.title}>{mode === 'login' ? 'Welcome back 👋' : 'Create account'}</h2>
        <p style={S.sub}>{mode === 'login' ? 'Sign in to continue' : 'Join QuickBite today'}</p>

        {/* Global error box */}
        {errors.non_field && (
          <div style={S.errBox}>⚠️ {errors.non_field}</div>
        )}

        <form onSubmit={submit}>

          {/* Username */}
          <div className="form-group">
            <label className="form-label">Username</label>
            <input
              className="form-input"
              style={errors.username ? S.inputErr : {}}
              value={form.username}
              onChange={set('username')}
              placeholder="e.g. john123"
              required
              autoFocus
            />
            {errors.username && <span style={S.fieldErr}>{errors.username}</span>}
          </div>

          {/* Register-only fields */}
          {mode === 'register' && (<>
            <div className="form-group">
              <label className="form-label">Email</label>
              <input
                className="form-input"
                style={errors.email ? S.inputErr : {}}
                type="email"
                value={form.email}
                onChange={set('email')}
                placeholder="you@email.com"
              />
              {errors.email && <span style={S.fieldErr}>{errors.email}</span>}
            </div>

            <div className="form-group">
              <label className="form-label">Phone Number</label>
              <input
                className="form-input"
                style={errors.phone_number ? S.inputErr : {}}
                value={form.phone_number}
                onChange={set('phone_number')}
                placeholder="9876543210"
              />
              {errors.phone_number && <span style={S.fieldErr}>{errors.phone_number}</span>}
            </div>

            <div className="form-group">
              <label className="form-label">Register As</label>
              <select className="form-input" value={form.role} onChange={set('role')}>
                <option value="CUSTOMER">🛍️ Customer — Order food</option>
                <option value="RESTAURANT">🏪 Restaurant Owner — Manage restaurant</option>
                <option value="DELIVERY">🛵 Delivery Partner — Deliver orders</option>
              </select>
            </div>
          </>)}

          {/* Password */}
          <div className="form-group">
            <label className="form-label">Password</label>
            <input
              className="form-input"
              style={errors.password ? S.inputErr : {}}
              type="password"
              value={form.password}
              onChange={set('password')}
              placeholder="Min 8 characters"
              required
            />
            {errors.password && <span style={S.fieldErr}>{errors.password}</span>}
            {mode === 'register' && !errors.password && (
              <span style={{ fontSize:11, color:'var(--muted)', marginTop:3 }}>
                Use 8+ characters. Avoid common words like "password123".
              </span>
            )}
          </div>

          <button
            className="btn btn-primary btn-full btn-lg"
            type="submit"
            disabled={busy}
            style={{ marginTop:10 }}
          >
            {busy
              ? '⏳ Please wait…'
              : mode === 'login' ? 'Sign In →' : 'Create Account →'
            }
          </button>
        </form>

        <p style={S.switchText}>
          {mode === 'login'
            ? <>New here? <span style={S.link} onClick={switchMode}>Create account</span></>
            : <>Already have an account? <span style={S.link} onClick={switchMode}>Sign in</span></>
          }
        </p>
      </div>
    </div>
  );
}

const S = {
  wrap:     { minHeight:'100vh', display:'flex', alignItems:'center', justifyContent:'center', padding:20, position:'relative' },
  bg:       { position:'fixed', inset:0, background:'var(--navy)', backgroundImage:'radial-gradient(circle at 20% 50%,rgba(249,115,22,.09) 0%,transparent 50%),radial-gradient(circle at 80% 20%,rgba(6,182,212,.09) 0%,transparent 50%)' },
  card:     { position:'relative', zIndex:1, background:'var(--surface)', border:'1px solid var(--border)', borderRadius:'var(--r-2xl)', padding:'40px 36px', width:440, maxWidth:'100%', boxShadow:'var(--sh-lg)', animation:'fadeIn .3s ease' },
  title:    { fontFamily:'var(--display)', fontSize:24, fontWeight:800, textAlign:'center', marginBottom:6 },
  sub:      { color:'var(--muted)', fontSize:14, textAlign:'center', marginBottom:24 },
  errBox:   { background:'rgba(239,68,68,.12)', border:'1px solid rgba(239,68,68,.35)', borderRadius:'var(--r-md)', padding:'10px 14px', fontSize:13, color:'var(--red)', marginBottom:16, lineHeight:1.5 },
  inputErr: { borderColor:'var(--red)', boxShadow:'0 0 0 3px rgba(239,68,68,.12)' },
  fieldErr: { fontSize:11, color:'var(--red)', marginTop:3 },
  switchText: { textAlign:'center', marginTop:22, fontSize:14, color:'var(--muted)' },
  link:     { color:'var(--teal)', fontWeight:700, cursor:'pointer' },
};
