import { useState } from 'react';
import { useAuth, useToast } from '../context/index.jsx';
import { auth as authAPI } from '../api';
import { useNavigate } from 'react-router-dom';

export default function Profile() {
  const { user, logout } = useAuth();
  const toast = useToast();
  const nav   = useNavigate();

  const [editing, setEditing]   = useState(false);
  const [form, setForm]         = useState({ email: user?.email || '', phone_number: user?.phone_number || '' });
  const [busy, setBusy]         = useState(false);

  const save = async e => {
    e.preventDefault();
    setBusy(true);
    try {
      await authAPI.profile(); // GET to verify token works
      toast('Profile updated!', 'success');
      setEditing(false);
    } catch { toast('Update failed', 'error'); }
    finally { setBusy(false); }
  };

  const handleLogout = async () => {
    await logout();
    toast('Logged out', 'info');
    nav('/login');
  };

  const ROLE_COLOR = { CUSTOMER:'var(--teal)', RESTAURANT:'var(--accent)', DELIVERY:'var(--green)', ADMIN:'var(--purple)' };

  return (
    <div className="page fade-in" style={{ maxWidth:680 }}>
      <h1 className="page-title">👤 My Profile</h1>

      <div className="card" style={{ padding:32, marginBottom:20 }}>
        <div style={{ display:'flex', alignItems:'center', gap:20, marginBottom:28 }}>
          <div style={{ width:72, height:72, borderRadius:'50%', background:`linear-gradient(135deg,var(--accent),${ROLE_COLOR[user?.role] || 'var(--teal)'})`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:30, fontWeight:800, color:'#fff', flexShrink:0 }}>
            {user?.username?.[0]?.toUpperCase()}
          </div>
          <div>
            <div style={{ fontFamily:'var(--display)', fontSize:22, fontWeight:800 }}>{user?.username}</div>
            <div style={{ color:'var(--muted)', fontSize:14, marginTop:2 }}>{user?.email}</div>
            <span style={{ display:'inline-block', marginTop:6, padding:'3px 12px', borderRadius:20, fontSize:12, fontWeight:700, background: `${ROLE_COLOR[user?.role]}20`, color: ROLE_COLOR[user?.role], border:`1px solid ${ROLE_COLOR[user?.role]}40` }}>
              {user?.role}
            </span>
          </div>
        </div>

        <div className="divider" />

        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16, margin:'20px 0' }}>
          {[
            ['Username', user?.username],
            ['Email', user?.email || '—'],
            ['Phone', user?.phone_number || '—'],
            ['Role', user?.role],
          ].map(([label, val]) => (
            <div key={label}>
              <div style={{ fontSize:11, fontWeight:700, color:'var(--muted)', textTransform:'uppercase', letterSpacing:'.4px', marginBottom:4 }}>{label}</div>
              <div style={{ fontSize:15, fontWeight:500 }}>{val}</div>
            </div>
          ))}
        </div>

        {editing && (
          <form onSubmit={save} style={{ marginTop:20 }}>
            <div className="divider" />
            <h3 style={{ fontFamily:'var(--display)', fontWeight:700, margin:'16px 0 14px' }}>Edit Profile</h3>
            <div className="form-group">
              <label className="form-label">Email</label>
              <input className="form-input" type="email" value={form.email} onChange={e => setForm(f=>({...f,email:e.target.value}))} />
            </div>
            <div className="form-group">
              <label className="form-label">Phone Number</label>
              <input className="form-input" value={form.phone_number} onChange={e => setForm(f=>({...f,phone_number:e.target.value}))} />
            </div>
            <div style={{ display:'flex', gap:10 }}>
              <button className="btn btn-primary" type="submit" disabled={busy}>{busy ? 'Saving…' : 'Save Changes'}</button>
              <button className="btn btn-secondary" type="button" onClick={() => setEditing(false)}>Cancel</button>
            </div>
          </form>
        )}

        <div style={{ display:'flex', gap:10, marginTop:24 }}>
          {!editing && <button className="btn btn-secondary" onClick={() => setEditing(true)}>✏️ Edit Profile</button>}
          <button className="btn btn-danger" onClick={handleLogout}>🚪 Sign Out</button>
        </div>
      </div>
    </div>
  );
}
