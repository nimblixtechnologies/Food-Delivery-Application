import { useState, useEffect } from 'react';
import { restaurants as rAPI, menuItems as menuAPI } from '../../api';
import { useToast } from '../../context/index.jsx';

const blank = { name:'', description:'', price:'', is_veg:true, is_available:true };

export default function MenuManagement() {
  const toast = useToast();
  const [items, setItems]     = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editItem, setEditItem]  = useState(null);
  const [form, setForm]         = useState(blank);
  const [busy, setBusy]         = useState(false);
  const [noRestaurant, setNoRestaurant] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const r = await rAPI.manage();
      setItems(r.menu?.items || []);
    } catch (err) {
      if (err?.status === 404) setNoRestaurant(true);
    } finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const openAdd = () => { setEditItem(null); setForm(blank); setShowForm(true); };
  const openEdit = (item) => { setEditItem(item); setForm({ name:item.name, description:item.description, price:item.price, is_veg:item.is_veg, is_available:item.is_available }); setShowForm(true); };

  const save = async e => {
    e.preventDefault();
    setBusy(true);
    try {
      const body = { ...form, price: parseFloat(form.price) };
      if (editItem) {
        await menuAPI.update(editItem.id, body);
        toast('Item updated!', 'success');
      } else {
        await menuAPI.add(body);
        toast('Item added!', 'success');
      }
      setShowForm(false);
      load();
    } catch (err) {
      toast(err?.data?.detail || err?.data?.error || 'Failed to save', 'error');
    } finally { setBusy(false); }
  };

  const deleteItem = async (id, name) => {
    if (!confirm(`Delete "${name}"?`)) return;
    try {
      await menuAPI.delete(id);
      toast('Item deleted', 'info');
      load();
    } catch { toast('Delete failed', 'error'); }
  };

  if (loading) return <div className="loading-wrap"><div className="spinner" /></div>;

  if (noRestaurant) return (
    <div className="page"><div className="empty-state"><div className="empty-icon">🏪</div><h3>Register your restaurant first</h3></div></div>
  );

  return (
    <div className="page fade-in">
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:24 }}>
        <h1 className="page-title" style={{ marginBottom:0 }}>🍽️ Menu Management</h1>
        <button className="btn btn-primary" onClick={openAdd}>+ Add Item</button>
      </div>

      {/* Form */}
      {showForm && (
        <div className="card" style={{ marginBottom:24, maxWidth:540 }}>
          <h3 style={{ fontFamily:'var(--display)', fontWeight:700, marginBottom:18 }}>
            {editItem ? `Edit: ${editItem.name}` : 'Add New Menu Item'}
          </h3>
          <form onSubmit={save}>
            <div className="form-group">
              <label className="form-label">Item Name</label>
              <input className="form-input" required value={form.name} onChange={e => setForm(f=>({...f,name:e.target.value}))} placeholder="e.g. Butter Chicken" />
            </div>
            <div className="form-group">
              <label className="form-label">Description</label>
              <textarea className="form-input" rows={2} value={form.description} onChange={e => setForm(f=>({...f,description:e.target.value}))} placeholder="Describe the dish…" />
            </div>
            <div className="grid2">
              <div className="form-group">
                <label className="form-label">Price (₹)</label>
                <input className="form-input" type="number" min="0" step="0.01" required value={form.price} onChange={e => setForm(f=>({...f,price:e.target.value}))} placeholder="0.00" />
              </div>
              <div className="form-group">
                <label className="form-label">Type</label>
                <select className="form-input" value={form.is_veg ? 'veg':'nonveg'} onChange={e => setForm(f=>({...f,is_veg:e.target.value==='veg'}))}>
                  <option value="veg">🌿 Vegetarian</option>
                  <option value="nonveg">🍖 Non-Vegetarian</option>
                </select>
              </div>
            </div>
            <div className="form-group">
              <label className="form-label">Availability</label>
              <select className="form-input" value={form.is_available ? 'yes':'no'} onChange={e => setForm(f=>({...f,is_available:e.target.value==='yes'}))}>
                <option value="yes">✅ Available</option>
                <option value="no">❌ Unavailable</option>
              </select>
            </div>
            <div style={{ display:'flex', gap:10 }}>
              <button className="btn btn-primary" type="submit" disabled={busy}>{busy ? 'Saving…' : editItem ? 'Update Item' : 'Add Item'}</button>
              <button className="btn btn-secondary" type="button" onClick={() => setShowForm(false)}>Cancel</button>
            </div>
          </form>
        </div>
      )}

      {/* Item list */}
      {items.length === 0 ? (
        <div className="empty-state"><div className="empty-icon">📋</div><h3>No menu items yet</h3><p>Add your first item using the button above</p></div>
      ) : (
        <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
          {items.map(item => (
            <div key={item.id} className="card" style={{ display:'flex', alignItems:'center', gap:16, padding:16 }}>
              <span style={{ width:10, height:10, borderRadius:'50%', background: item.is_veg ? 'var(--green)' : 'var(--red)', flexShrink:0 }} />
              <div style={{ flex:1 }}>
                <div style={{ fontWeight:700, fontSize:15, marginBottom:2 }}>{item.name}</div>
                {item.description && <div style={{ fontSize:13, color:'var(--muted)', marginBottom:4 }}>{item.description}</div>}
                <div style={{ display:'flex', gap:10, alignItems:'center' }}>
                  <span style={{ fontWeight:800, color:'var(--accent)', fontSize:15 }}>₹{item.price}</span>
                  <span className={`badge ${item.is_available ? 'badge-green' : 'badge-red'}`} style={{ fontSize:10 }}>
                    {item.is_available ? 'Available' : 'Unavailable'}
                  </span>
                  <span className="badge badge-teal" style={{ fontSize:10 }}>{item.is_veg ? 'Veg' : 'Non-Veg'}</span>
                </div>
              </div>
              <div style={{ display:'flex', gap:8 }}>
                <button className="btn btn-secondary btn-sm" onClick={() => openEdit(item)}>✏️ Edit</button>
                <button className="btn btn-danger btn-sm" onClick={() => deleteItem(item.id, item.name)}>🗑️</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
