// All endpoints match exactly what's in your Django urls.py files
// Auth uses Token: "Token <key>" header (rest_framework.authtoken)

const BASE = '/api/v1';

const getToken = () => localStorage.getItem('qb_token');

function authHeaders() {
  const token = getToken();
  return {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Token ${token}` } : {}),
  };
}

async function req(path, opts = {}) {
  const res = await fetch(`${BASE}${path}`, {
    ...opts,
    headers: { ...authHeaders(), ...(opts.headers || {}) },
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw { status: res.status, data };
  return data;
}

/* ── AUTH  (api/v1/users/) ──────────────────────────────────── */
export const auth = {
  // POST /api/v1/users/register/  { username, email, password, phone_number, role }
  register: (body) => req('/users/register/', { method: 'POST', body }),

  // POST /api/v1/users/login/     { username, password }  → { token }
  login: (body) => req('/users/login/', { method: 'POST', body }),

  // POST /api/v1/users/logout/
  logout: () => req('/users/logout/', { method: 'POST' }),

  // GET  /api/v1/users/profile/   → { id, username, email, phone_number, role, addresses }
  profile: () => req('/users/profile/'),
};

/* ── RESTAURANTS  (api/v1/restaurants/) ─────────────────────── */
export const restaurants = {
  // GET  /api/v1/restaurants/                           → list (public, approved only)
  list: () => req('/restaurants/'),

  // GET  /api/v1/restaurants/<id>/                      → single restaurant with menu
  detail: (id) => req(`/restaurants/${id}/`),

  // GET  /api/v1/restaurants/<id>/menu/                 → { id, items: [...] }
  menu: (id) => req(`/restaurants/${id}/menu/`),

  // POST /api/v1/restaurants/register/   { name, address, contact_number }  (RESTAURANT role)
  create: (body) => req('/restaurants/register/', { method: 'POST', body }),

  // GET/PUT /api/v1/restaurants/manage/   (owner's own restaurant)
  manage: () => req('/restaurants/manage/'),
  update: (body) => req('/restaurants/manage/', { method: 'PUT', body }),
};

/* ── MENU ITEMS  (api/v1/restaurants/menu/items/) ────────────── */
export const menuItems = {
  // POST /api/v1/restaurants/menu/items/add/   { name, description, price, is_veg, is_available }
  add: (body) => req('/restaurants/menu/items/add/', { method: 'POST', body }),

  // PUT/DELETE /api/v1/restaurants/menu/items/<id>/
  update: (id, body) => req(`/restaurants/menu/items/${id}/`, { method: 'PUT', body }),
  delete: (id) => req(`/restaurants/menu/items/${id}/`, { method: 'DELETE' }),
};

/* ── CART  (api/v1/orders/cart/) ────────────────────────────── */
export const cart = {
  // GET  /api/v1/orders/cart/   → { id, items: [...], total_price }
  get: () => req('/orders/cart/'),

  // POST /api/v1/orders/cart/   { menu_item_id, quantity }
  addItem: (menu_item_id, quantity = 1) => req('/orders/cart/', { method: 'POST', body: { menu_item_id, quantity } }),

  // DELETE /api/v1/orders/cart/items/<id>/
  removeItem: (id) => req(`/orders/cart/items/${id}/`, { method: 'DELETE' }),

  // DELETE /api/v1/orders/cart/   (clear all)
  clear: () => req('/orders/cart/', { method: 'DELETE' }),
};

/* ── ORDERS  (api/v1/orders/) ───────────────────────────────── */
export const orders = {
  // GET  /api/v1/orders/           → list (customer's own orders)
  list: () => req('/orders/'),

  // POST /api/v1/orders/checkout/  { delivery_address }  → places order from cart
  checkout: (delivery_address) => req('/orders/checkout/', { method: 'POST', body: { delivery_address } }),

  // POST /api/v1/orders/<id>/cancel/
  cancel: (id) => req(`/orders/${id}/cancel/`, { method: 'POST' }),

  // PUT  /api/v1/orders/<id>/update-status/   { status }  (restaurant/admin)
  updateStatus: (id, status) => req(`/orders/${id}/update-status/`, { method: 'PUT', body: { status } }),
};

/* ── DELIVERY  (api/v1/delivery/) ───────────────────────────── */
export const delivery = {
  // GET  /api/v1/delivery/status/   → my deliveries
  myDeliveries: () => req('/delivery/status/'),

  // POST /api/v1/delivery/status/   { is_available, current_location }
  updateStatus: (body) => req('/delivery/status/', { method: 'POST', body }),

  // GET  /api/v1/delivery/orders/available/   → PREPARING orders without partner
  availableOrders: () => req('/delivery/orders/available/'),

  // POST /api/v1/delivery/orders/<id>/accept/
  acceptOrder: (order_id) => req(`/delivery/orders/${order_id}/accept/`, { method: 'POST' }),

  // POST /api/v1/delivery/<pk>/status/   { status: PICKED_UP | ON_THE_WAY | DELIVERED }
  updateDeliveryStatus: (pk, status) => req(`/delivery/${pk}/status/`, { method: 'POST', body: { status } }),
};

/* ── REVIEWS  (api/v1/reviews/) ─────────────────────────────── */
export const reviews = {
  // POST /api/v1/reviews/   { order_id, rating, comment }
  create: (body) => req('/reviews/', { method: 'POST', body }),
};

/* ── PAYMENTS  (api/v1/payments/) ───────────────────────────── */
export const payments = {
  list: () => req('/payments/'),
  create: (body) => req('/payments/create/', { method: 'POST', body }),
};

/* ── PROMO  (api/v1/promo/) ─────────────────────────────────── */
export const promo = {
  validate: (code) => req('/promo/validate/', { method: 'POST', body: { code } }),
};

/* ── NOTIFICATIONS  (api/v1/notifications/) ─────────────────── */
export const notifications = {
  list: () => req('/notifications/'),
  markRead: (pk) => req(`/notifications/${pk}/read/`, { method: 'POST' }),
};
