import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { AuthProvider, ToastProvider, useAuth } from './context/index.jsx';
import Navbar from './components/Navbar.jsx';

// Pages
import AuthPage           from './pages/Auth.jsx';
import Profile            from './pages/Profile.jsx';
// Customer
import CustomerHome       from './pages/customer/Home.jsx';
import RestaurantDetail   from './pages/customer/RestaurantDetail.jsx';
import MyOrders           from './pages/customer/Orders.jsx';
// Restaurant
import RestaurantDashboard from './pages/restaurant/Dashboard.jsx';
import MenuManagement     from './pages/restaurant/Menu.jsx';
// Delivery
import DeliveryDashboard  from './pages/delivery/Dashboard.jsx';
import DeliveryHistory    from './pages/delivery/History.jsx';

/* ── Guards ─────────────────────────────────────────────────── */
function RequireAuth({ children }) {
  const { user, loading } = useAuth();
  const loc = useLocation();
  if (loading) return null;
  if (!user) return <Navigate to="/login" state={{ from: loc }} replace />;
  return children;
}

function RequireRole({ role, children }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (user.role !== role) return <Navigate to="/" replace />;
  return children;
}

function RoleRedirect() {
  const { user, loading } = useAuth();
  if (loading) return null;
  if (!user) return <Navigate to="/login" replace />;
  if (user.role === 'RESTAURANT') return <Navigate to="/restaurant" replace />;
  if (user.role === 'DELIVERY')   return <Navigate to="/delivery"   replace />;
  return <Navigate to="/home" replace />;
}

/* ── Layout ─────────────────────────────────────────────────── */
function Layout({ children }) {
  const { user } = useAuth();
  return (
    <>
      {user && <Navbar />}
      {children}
    </>
  );
}

/* ── Routes ─────────────────────────────────────────────────── */
function AppRoutes() {
  const { user } = useAuth();
  return (
    <Layout>
      <Routes>
        {/* Public */}
        <Route path="/login" element={user ? <RoleRedirect /> : <AuthPage />} />

        {/* Root redirect */}
        <Route path="/" element={<RoleRedirect />} />

        {/* ── CUSTOMER ── */}
        <Route path="/home" element={
          <RequireRole role="CUSTOMER"><CustomerHome /></RequireRole>
        } />
        <Route path="/restaurant/:id" element={
          <RequireAuth><RestaurantDetail /></RequireAuth>
        } />
        <Route path="/orders" element={
          <RequireRole role="CUSTOMER"><MyOrders /></RequireRole>
        } />

        {/* ── RESTAURANT ── */}
        <Route path="/restaurant" element={
          <RequireRole role="RESTAURANT"><RestaurantDashboard /></RequireRole>
        } />
        <Route path="/restaurant/menu" element={
          <RequireRole role="RESTAURANT"><MenuManagement /></RequireRole>
        } />
        <Route path="/restaurant/orders" element={
          <RequireRole role="RESTAURANT"><RestaurantDashboard /></RequireRole>
        } />

        {/* ── DELIVERY ── */}
        <Route path="/delivery" element={
          <RequireRole role="DELIVERY"><DeliveryDashboard /></RequireRole>
        } />
        <Route path="/delivery/available" element={
          <RequireRole role="DELIVERY"><DeliveryDashboard /></RequireRole>
        } />
        <Route path="/delivery/history" element={
          <RequireRole role="DELIVERY"><DeliveryHistory /></RequireRole>
        } />

        {/* ── PROFILE (all roles) ── */}
        <Route path="/profile" element={
          <RequireAuth><Profile /></RequireAuth>
        } />

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Layout>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <ToastProvider>
          <AppRoutes />
        </ToastProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}
