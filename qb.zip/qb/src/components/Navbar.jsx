import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/index.jsx';
import { useToast } from '../context/index.jsx';

const NAV_LINKS = {
  CUSTOMER:   [['/', 'Home'], ['/orders', 'My Orders'], ['/profile', 'Profile']],
  RESTAURANT: [['/restaurant', 'Dashboard'], ['/restaurant/menu', 'Menu'], ['/restaurant/orders', 'Orders'], ['/profile', 'Profile']],
  DELIVERY:   [['/delivery', 'Dashboard'], ['/delivery/available', 'Available Orders'], ['/delivery/history', 'History'], ['/profile', 'Profile']],
  ADMIN:      [['/', 'Home']],
};

export default function Navbar() {
  const { user, logout } = useAuth();
  const toast  = useToast();
  const loc    = useLocation();
  const nav    = useNavigate();

  const links = NAV_LINKS[user?.role] || [];

  const handleLogout = async () => {
    await logout();
    toast('Logged out successfully', 'info');
    nav('/login');
  };

  return (
    <nav className="navbar">
      <div className="navbar-inner">
        <div className="logo">Quick<span>Bite</span></div>
        <div style={{ display:'flex', gap:4, marginLeft:16 }}>
          {links.map(([path, label]) => (
            <Link
              key={path}
              to={path}
              className={`nav-link ${loc.pathname === path ? 'active' : ''}`}
            >
              {label}
            </Link>
          ))}
        </div>
        <div className="nav-spacer" />
        {user && (
          <div style={{ display:'flex', alignItems:'center', gap:10 }}>
            <div className="nav-user">
              <div className="nav-avatar">{user.username?.[0]?.toUpperCase()}</div>
              <span>{user.username}</span>
              <span className={`nav-role nav-role-${user.role}`}>{user.role}</span>
            </div>
            <button className="btn btn-secondary btn-sm" onClick={handleLogout}>Logout</button>
          </div>
        )}
      </div>
    </nav>
  );
}
